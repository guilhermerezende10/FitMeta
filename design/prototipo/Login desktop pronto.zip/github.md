repo: guilhermerezende10/FitMeta
branch: develop

## Last sync
date: 2026-08-27T11:24:00Z

### Updated in this project
- Hub de Estudos Científicos + as quatro páginas de categoria, com conteúdo verbatim de `src/data/data-estudos-cientificos.js`.
- Contagem real de estudos por categoria no chip (5 / 7 / 1 / 4); emojis dos títulos removidos e campo `source` exibido pela primeira vez.
- Roteamento interno no shell cobrindo todas as rotas: Home, Estudos (hub + 4 categorias), formulários de treino e nutrição, Meu Treino, Minha Nutrição, Motivacional e 404.
- Formulário único para os dois fluxos, com stepper, validação de campo, salvamento e erro de servidor; telas de resultado com dados reais (`nome`, `faixaRep`, macros).
- Área motivacional com as 20 pessoas de `data-motivacional.js`, sem autoplay e sem asteriscos de markdown.
- Login/Cadastro/Legais continuam em `FitMeta Auth.dc.html` e `FitMeta Legal.dc.html`, agora ligados ao app (Entrar → shell, Sair → login, Voltar dos legais → cadastro).

## Sync history
- 2026-08-26T20:16:12Z — `develop`: páginas legais + logo real; design system em `design/fitmeta-design-system.md`.
- 2026-08-26T18:43:38Z — `develop`: árvore lida; `design/` localizado.
- 2026-08-26T18:41:29Z — `main`: importado `src/data/logo/logo-white.png`.

## Screen map
| Tela do projeto | Arquivos do repositório |
|---|---|
| FitMeta Auth.dc.html — Login/Cadastro | src/data/logo/logo-white.png, src/pages/Login.jsx, src/pages/Register.jsx |
| FitMeta Legal.dc.html — Política + Termos | src/pages/PoliticasPrivacidade.jsx, src/pages/TermosDeUso.jsx |
| FitMeta Shell.dc.html — Estudos (hub + categorias) | src/data/data-estudos-cientificos.js |
| FitMeta Shell.dc.html — Formulários treino/nutrição | src/pages/TreinoSelect.jsx, src/pages/NutricaoSelect.jsx |
| FitMeta Shell.dc.html — Meu Treino | src/data/data-recomendacao-treino.js |
| FitMeta Shell.dc.html — Motivacional | src/data/data-motivacional.js |
